package com.tudresden.cordasamples.auctioncontract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctioncontractApplicationTests {

	@Test
	void contextLoads() {
	}

}
