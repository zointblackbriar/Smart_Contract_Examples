package com.tudresden.cordasamples.auctioncontract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctioncontractApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuctioncontractApplication.class, args);
	}

}
